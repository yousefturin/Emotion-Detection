# DatasetImages7Classes

<https://www.kaggle.com/datasets/jonathanoheix/face-expression-recognition-dataset/code>
