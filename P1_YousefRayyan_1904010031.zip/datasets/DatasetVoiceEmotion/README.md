# DatasetVoiceEmotion

<https://drive.google.com/drive/folders/1BPsVxWnyrIpgJviW3fa-elXVTikBhRLE?usp=sharing>
