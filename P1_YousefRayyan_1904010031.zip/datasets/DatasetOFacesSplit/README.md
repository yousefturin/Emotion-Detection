# DatasetOFacesSplit

<https://drive.google.com/drive/folders/1ob3IjtADsdTe-heUsAzdGeTySu0WbqlN?usp=drive_link>
